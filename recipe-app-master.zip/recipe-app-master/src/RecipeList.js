import React from 'react';
import { Link } from 'react-router-dom';

const RecipeList = ({ recipes, setRecipes }) => {
    const deleteRecipe = (id) => {
        setRecipes(recipes.filter((recipe) => recipe.id !== id));
    };

    return (
        <div>
            <h2>Recipe List</h2>
            <Link to="/recipes/new">Create New Recipe</Link>
            <ul>
                {recipes.map((recipe) => (
                    <li key={recipe.id}>
                        <Link to={`/recipes/${recipe.id}`}>{recipe.name}</Link>
                        <button onClick={() => deleteRecipe(recipe.id)}>Delete</button>
                        <Link to={`/recipes/edit/${recipe.id}`}><button> Edit</button></Link>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default RecipeList;