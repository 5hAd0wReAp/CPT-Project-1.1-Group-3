import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useNavigate } from 'react-router-dom';
import RecipeList from './RecipeList';
import RecipeForm from './RecipeForm';
import RecipeDetail from './RecipeDetail';
import Login from './Login';

const App = () => {
  const [recipes, setRecipes] = useState([]);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const navigate = useNavigate();

  const authenticateUser = (username, password) => {
    if (username === 'user' && password === 'password') {
      setIsAuthenticated(true);
      navigate('/recipes');
    } else {
      alert('Invalid username or password');
    }
  };

  const logout = () => {
    setIsAuthenticated(false);
    navigate('/');
  };

  useEffect(() => {
    const storedRecipes = JSON.parse(localStorage.getItem('recipes')) || [];
    setRecipes(storedRecipes);
  }, []);

  const saveRecipesToLocalStorage = () => {
    localStorage.setItem('recipes', JSON.stringify(recipes));
  };

  useEffect(() => {
    if (recipes.length > 0) {
      saveRecipesToLocalStorage();
    }
  }, [recipes]);

  if (!isAuthenticated) {
    return <Login authenticateUser={authenticateUser} />;
  }

  return (
      <div>
        <nav>
          <Link to="/recipes">Recipes</Link>
          <button onClick={logout}>Logout</button>
        </nav>

        <Routes>
          <Route path="/recipes" element={<RecipeList recipes={recipes} setRecipes={setRecipes} />} />
          <Route path="/recipes/new" element={<RecipeForm recipes={recipes} setRecipes={setRecipes} />} />
          <Route path="/recipes/edit/:id" element={<RecipeForm recipes={recipes} setRecipes={setRecipes} />} />
          <Route path="/recipes/:id" element={<RecipeDetail recipes={recipes} />} />
          <Route path="/" element={<Login authenticateUser={authenticateUser} />} />
        </Routes>
      </div>
  );
};

export default App;
