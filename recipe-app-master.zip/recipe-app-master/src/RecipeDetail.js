import React from 'react';
import { useParams } from 'react-router-dom';

const RecipeDetail = ({ recipes }) => {
    const { id } = useParams();
    const recipe = recipes.find((recipe) => recipe.id === parseInt(id));

    if (!recipe) {
        return <p>Recipe not found!</p>
    }

    return (
        <div>
            <h2>{recipe.name}</h2>
            <h3>Steps</h3>
            <ul>
                {recipe.steps.map((step, idx) => (
                    <li key={idx}>{step.step} (Time: {step.time} min)</li>
                ))}
            </ul>
            <h3>Ingredients</h3>
            <ul>
                {recipe.ingredients.map((ingredient, idx) => (
                    <li key={idx}>{ingredient}</li>
                ))}
            </ul>
        </div>
    );
};

export default RecipeDetail;