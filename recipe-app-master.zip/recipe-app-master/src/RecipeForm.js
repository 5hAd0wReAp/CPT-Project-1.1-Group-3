import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const RecipeForm = ({ recipes, setRecipes }) => {
    const [name, setName] = useState('');
    const [steps, setSteps] = useState([]);
    const [ingredients, setIngredients] = useState([]);
    const [currentStep, setCurrentStep] = useState('');
    const [currentIngredient, setCurrentIngredient] = useState('');
    const [stepTime, setStepTime] = useState('');
    const { id } = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        if (id) {
            const recipe = recipes.find((recipe) => recipe.id === parseInt(id));
            if (recipe) {
                setName(recipe.name);
                setSteps(recipe.steps);
                setIngredients(recipe.ingredients);
            }
        }
    }, [id, recipes]);

    const handleSaveRecipe = () => {
        if (!name || steps.length === 0 || ingredients.length === 0) {
            alert('Please provide all fields!');
            return;
        }

        const newRecipe = {
            id: id ? parseInt(id) : Date.now(),
            name,
            steps,
            ingredients,
        };

        let storedRecipes = JSON.parse(localStorage.getItem('recipes')) || [];

        if (id) {
            storedRecipes = storedRecipes.map((recipe) => recipe.id === newRecipe.id ? newRecipe : recipe);
        } else {
            storedRecipes.push(newRecipe);
        }
        
        localStorage.setItem('recipes', JSON.stringify(storedRecipes));

        setRecipes(storedRecipes);

        navigate('/recipes');
    };

    const addStep = () => {
        if (!currentStep || !stepTime) {
            alert('Step and Time are required!');
            return;
        }
        setSteps([...steps, { step: currentStep, time: stepTime }]);
        setCurrentStep('');
        setStepTime('');
    };

    const addIngredient = () => {
        if (!currentIngredient) {
            alert('Ingredient is required!');
            return;
        }
        setIngredients([...ingredients, currentIngredient]);
        setCurrentIngredient('');
    };

    return (
        <div>
            <h2>{id ? 'Edit Recipe' : 'Create Recipe'}</h2>
            <input
                type="text"
                placeholder="Recipe Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
            />
            <h3>Steps</h3>
            <input
                type="text"
                placeholder="Step Description"
                value={currentStep}
                onChange={(e) => setCurrentStep(e.target.value)}
            />
            <input
                type="number"
                placeholder="Estimated Time (min)"
                value={stepTime}
                onChange={(e) => setStepTime(e.target.value)}
            />
            <button onClick={addStep}>Add Step</button>
            <ul>
                {steps.map((step, idx) => (
                    <li key={idx}>
                        {step.step} (Time: {step.time} min)
                    </li>
                ))}
            </ul>

            <h3>Ingredients</h3>
            <input
                type="text"
                placeholder="Ingredient"
                value={currentIngredient}
                onChange={(e) => setCurrentIngredient(e.target.value)}
            />
            <button onClick={addIngredient}>Add Ingredient</button>
            <ul>
                {ingredients.map((ingredient, idx) => (
                    <li key={idx}>{ingredient}</li>
                ))}
            </ul>

            <button onClick={handleSaveRecipe}>Save Recipe</button>
        </div>
    );
};

export default RecipeForm;